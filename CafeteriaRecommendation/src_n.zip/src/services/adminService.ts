import { Request, Response } from 'express';
import { menuRepository } from '../repositories/menuRepository';
import { MenuItemPayload } from '../utils/types';

export async function addMenuItem({ name, price, availability }: MenuItemPayload, callback: Function) {
  try {
    const menuItemId = await menuRepository.addMenuItem({ name, price, availability });
    callback({ success: true, menuItemId });
  } catch (err) {
    console.error('Error adding menu item:', err);
    callback({ success: false });
  }
}

export async function updateMenuItem({ id, name, price, availability }: MenuItemPayload, callback: Function) {
  try {
    await menuRepository.updateMenuItem({ id, name, price, availability });
    callback({ success: true });
  } catch (err) {
    console.error('Error updating menu item:', err);
    callback({ success: false });
  }
}

export async function deleteMenuItem(id: number, callback: Function) {
  try {
    await menuRepository.deleteMenuItem(id);
    callback({ success: true });
  } catch (err) {
    console.error('Error deleting menu item:', err);
    callback({ success: false });
  }
}

export async function viewMenu(callback: Function) {
  try {
    const menuItems = await menuRepository.viewMenu();
    callback({ success: true, menuItems });
  } catch (err) {
    console.error('Error viewing menu:', err);
    callback({ success: false });
  }
}
