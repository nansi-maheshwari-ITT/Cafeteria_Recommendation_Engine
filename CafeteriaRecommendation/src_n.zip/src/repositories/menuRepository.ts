import connection from "../utils/database";
import { MenuItemPayload } from "../utils/types";


class MenuRepository {
  async addMenuItem({ name, price, availability }: MenuItemPayload) {
    const [results] = await connection.query('INSERT INTO menu_items (name, price, availability) VALUES (?, ?, ?)', [name, price, availability]);
    return (results as any).insertId;
  }

  async updateMenuItem({ id, name, price, availability }: MenuItemPayload) {
    await connection.query('UPDATE menu_items SET name = ?, price = ?, availability = ? WHERE id = ?', [name, price, availability, id]);
  }

  async deleteMenuItem(id: number) {
    await connection.query('DELETE FROM menu_items WHERE id = ?', [id]);
  }

  async viewMenu() {
    const [rows] = await connection.query('SELECT * FROM menu_items');
    return rows;
  }

  async recommendMenu(itemIds: number[]) {
    const [rows] = await connection.query('SELECT * FROM menu_items WHERE id IN (?)', [itemIds]);
    return rows;
  }

  async viewMonthlyFeedback() {
    const [rows] = await connection.query(`
      SELECT menu_items.name, AVG(feedback.rating) as average_rating, COUNT(feedback.id) as feedback_count
      FROM feedback
      JOIN menu_items ON feedback.menu_item_id = menu_items.id
      WHERE feedback_date >= DATE_SUB(CURDATE(), INTERVAL 1 MONTH)
      GROUP BY menu_items.name
    `);
    return rows;
  }
}

export const menuRepository = new MenuRepository();
